﻿using System.Collections.Generic;
using fernandez.northwind.Roles.Dto;

namespace fernandez.northwind.Web.Models.Roles
{
    public class RoleListViewModel
    {
        public IReadOnlyList<RoleDto> Roles { get; set; }

        public IReadOnlyList<PermissionDto> Permissions { get; set; }
    }
}