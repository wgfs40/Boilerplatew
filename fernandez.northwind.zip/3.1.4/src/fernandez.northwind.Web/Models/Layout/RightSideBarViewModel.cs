using fernandez.northwind.Configuration.Ui;

namespace fernandez.northwind.Web.Models.Layout
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}