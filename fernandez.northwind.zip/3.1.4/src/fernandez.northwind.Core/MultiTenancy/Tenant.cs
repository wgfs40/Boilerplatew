﻿using Abp.MultiTenancy;
using fernandez.northwind.Authorization.Users;

namespace fernandez.northwind.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}