﻿namespace fernandez.northwind
{
    public class northwindConsts
    {
        public const string LocalizationSourceName = "northwind";

        public const bool MultiTenancyEnabled = true;
    }
}